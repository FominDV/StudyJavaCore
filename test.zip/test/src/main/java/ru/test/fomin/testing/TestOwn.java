package ru.test.fomin.testing;

import javax.sound.midi.Soundbank;
import java.util.Arrays;

public class TestOwn {
    public static void main(String[] args) {
      byte a =127;
      a++;
      System.out.print(a);


    }
}
